#include "board.h"
//#include<SFML>
#include <SFML/Graphics.hpp>

#include"utility.h"

board::board() {
	noOfPlayers = 0;
}
board::board(int n) {
	
	noOfPlayers = n;
	
	for (int i = 0; i < n; i++)
	{
		Color color = static_cast<Color>(i);
		player p(color);
		pls.push_back(p);
		
	}

}
void board::drawSquare(sf::RenderWindow& window, sf::Vector2f position, sf::Color color,float t)
{
	sf::RectangleShape square(sf::Vector2f(SQUARE_SIZE3, SQUARE_SIZE3));
	square.setPosition(position);
	square.setFillColor(color);
	square.setOutlineThickness(1.f);
	square.setOutlineColor(sf::Color::Black);
	window.draw(square);
}
void board::printBoard(sf::RenderWindow& window) {
	//// Blue color
	//sf::Color blue(135, 206, 235);

	//// Red color
	//sf::Color red(255, 192, 203);

	//// Yellow color
	//sf::Color yellow(238, 232, 170);

	//// Green color
	//sf::Color green(152, 251, 152);

	//// White color
	//sf::Color white = sf::Color::White;
	//for (float i = 0; i <= 1.5; i += 1.5)
	//{
	//	for (float j = 0; j <= 3; j += 1.5) {
	//		sf::RectangleShape square(sf::Vector2f(SQUARE_SIZE, SQUARE_SIZE));
	//		square.setPosition(sf::Vector2f(i * SQUARE_SIZE, j * SQUARE_SIZE));
	//		if (i == 0 && j == 0) {
	//			square.setFillColor(red);
	//		}
	//		if (i == 1.5 && j == 0) {
	//			square.setFillColor(green);
	//		}
	//		if (i == 0 && j == 1.5) {
	//			square.setFillColor(blue);
	//		}
	//		if (i == 1.5 && j == 1.5) {
	//			square.setFillColor(yellow);
	//		}
	//		window.draw(square);
	//		sf::RectangleShape square11(sf::Vector2f(SQUARE_SIZE2, SQUARE_SIZE2));
	//		square11.setPosition(sf::Vector2f(i * SQUARE_SIZE + 50, j * SQUARE_SIZE + 50));
	//		square11.setFillColor(white);
	//		window.draw(square11);
	//	}

	//}
	////sf::RectangleShape square2(sf::Vector2f(SQUARE_SIZE, SQUARE_SIZE));



	//sf::ConvexShape triangle;
	//triangle.setPointCount(3); // 3 points for a triangle
	//triangle.setPoint(0, sf::Vector2f(400, 400)); // first point
	//triangle.setPoint(1, sf::Vector2f(600, 400)); // second point
	//triangle.setPoint(2, sf::Vector2f(500, 500)); // third point
	//triangle.setFillColor(green); // set fill color of the triangle
	//triangle.setOutlineColor(sf::Color::Black); // set outline color of the triangle
	//triangle.setOutlineThickness(2); // set thickness of the outline
	//window.draw(triangle);

	//triangle.setPointCount(3); // 3 points for a triangle
	//triangle.setPoint(0, sf::Vector2f(400, 400)); // first point
	//triangle.setPoint(1, sf::Vector2f(400, 600)); // second point
	//triangle.setPoint(2, sf::Vector2f(500, 500)); // third point
	//triangle.setFillColor(red); // set fill color of the triangle
	//triangle.setOutlineColor(sf::Color::Black); // set outline color of the triangle
	//triangle.setOutlineThickness(2); // set thickness of the outline
	//window.draw(triangle);

	//triangle.setPointCount(3); // 3 points for a triangle
	//triangle.setPoint(0, sf::Vector2f(400, 600)); // first point
	//triangle.setPoint(1, sf::Vector2f(600, 600)); // second point
	//triangle.setPoint(2, sf::Vector2f(500, 500)); // third point
	//triangle.setFillColor(blue); // set fill color of the triangle
	//triangle.setOutlineColor(sf::Color::Black); // set outline color of the triangle
	//triangle.setOutlineThickness(2); // set thickness of the outline
	//window.draw(triangle);

	//triangle.setPointCount(3); // 3 points for a triangle
	//triangle.setPoint(0, sf::Vector2f(600, 600)); // first point
	//triangle.setPoint(1, sf::Vector2f(600, 400)); // second point
	//triangle.setPoint(2, sf::Vector2f(500, 500)); // third point
	//triangle.setFillColor(yellow); // set fill color of the triangle
	//triangle.setOutlineColor(sf::Color::Black); // set outline color of the triangle
	//triangle.setOutlineThickness(2); // set thickness of the outline
	//window.draw(triangle);


	//for (int i = 0; i < 6; i++)
	//{
	//	for (int j = 0; j < 3; j++) {


	//		if (j == 1 && i > 0) {
	//			drawSquare(window, sf::Vector2f(i * SQUARE_SIZE3, SQUARE_SIZE + (j * SQUARE_SIZE3)), red);
	//		}
	//		else {
	//			drawSquare(window, sf::Vector2f(i * SQUARE_SIZE3, SQUARE_SIZE + (j * SQUARE_SIZE3)), white);
	//		}

	//	}
	//}
	//drawSquare(window, sf::Vector2f(1 * SQUARE_SIZE3, SQUARE_SIZE + (0 * SQUARE_SIZE3)), red);
	//drawSquare(window, sf::Vector2f(2 * SQUARE_SIZE3, SQUARE_SIZE + (2 * SQUARE_SIZE3)), red);
	//for (int i = 0; i < 6; i++)
	//{
	//	for (int j = 0; j < 3; j++) {

	//		if (j == 1 && i > 0) {
	//			drawSquare(window, sf::Vector2f(SQUARE_SIZE + (j * SQUARE_SIZE3), i * SQUARE_SIZE3), green);
	//		}
	//		else {
	//			drawSquare(window, sf::Vector2f(SQUARE_SIZE + (j * SQUARE_SIZE3), i * SQUARE_SIZE3), white);
	//		}
	//	}
	//}
	//drawSquare(window, sf::Vector2f(SQUARE_SIZE + (2 * SQUARE_SIZE3), 1 * SQUARE_SIZE3), green);
	//drawSquare(window, sf::Vector2f(SQUARE_SIZE + (0 * SQUARE_SIZE3), 2 * SQUARE_SIZE3), green);
	//for (int i = 0; i < 6; i++)
	//{
	//	for (int j = 0; j < 3; j++) {

	//		if (j == 1 && i < 5) {
	//			drawSquare(window, sf::Vector2f(SQUARE_SIZE + (i * SQUARE_SIZE3) + 205, SQUARE_SIZE + (j * SQUARE_SIZE3)), yellow);
	//		}
	//		else {
	//			drawSquare(window, sf::Vector2f(SQUARE_SIZE + (i * SQUARE_SIZE3) + 205, SQUARE_SIZE + (j * SQUARE_SIZE3)), white);
	//		}
	//	}
	//}
	//drawSquare(window, sf::Vector2f(SQUARE_SIZE + (4 * SQUARE_SIZE3) + 205, SQUARE_SIZE + (2 * SQUARE_SIZE3)), yellow);
	//drawSquare(window, sf::Vector2f(SQUARE_SIZE + (3 * SQUARE_SIZE3) + 205, SQUARE_SIZE + (0 * SQUARE_SIZE3)), yellow);
	//for (int i = 0; i < 6; i++)
	//{
	//	for (int j = 0; j < 3; j++) {
	//		if (j == 1 && i < 5) {
	//			drawSquare(window, sf::Vector2f(SQUARE_SIZE + (j * SQUARE_SIZE3), SQUARE_SIZE + (i * SQUARE_SIZE3) + 205), blue);
	//		}
	//		else {

	//			drawSquare(window, sf::Vector2f(SQUARE_SIZE + (j * SQUARE_SIZE3), SQUARE_SIZE + (i * SQUARE_SIZE3) + 205), white);
	//		}
	//	}
	//}
	//drawSquare(window, sf::Vector2f(SQUARE_SIZE + (0 * SQUARE_SIZE3), SQUARE_SIZE + (4 * SQUARE_SIZE3) + 205), blue);
	//drawSquare(window, sf::Vector2f(SQUARE_SIZE + (2 * SQUARE_SIZE3), SQUARE_SIZE + (3 * SQUARE_SIZE3) + 205), blue);
	//
	sf::Texture board;
	if (!board.loadFromFile("ludoo.png"))
		return;

	sf::Sprite s(board);
	s.setScale(1, 1);
	window.draw(s);
	for (int i = 0; i < pls.size(); i++)
	{
		for (int j = 0; j < pls[i].ps.size(); j++)
		{
			pls[i].ps[j].drawPiece(window);
		}
	}

	
}