#pragma once

class dice {
public:
	void roll() {

	}
	int moves;

};