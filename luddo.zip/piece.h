#pragma once
#include <SFML/Graphics.hpp>

#include"utility.h"
class piece
{
public:
	piece();
	piece(Color color, pos p, pos sp= { 1,1 },pos offSet={0,0});
	void setClr(Color clrr) { color_ = clrr; }
	Color get_color() const { return color_; }
	int get_position() const { return position_; }
	void set_position(int position) { position_ = position; }
	void set_current_position(sf::Vector2f position) { currentPosition = position; }
	void move(int x=0);
	bool hasKilled;
	sf::Vector2f startPos;
	pos offSet_;
	void setPos(pos p);
	void drawPiece(sf::RenderWindow& window);
	bool isClicked(sf::Vector2f position);
	sf::Vector2f currentPosition;
private:
	Color color_;
	int position_;
	pos position;
	
	sf::Vector2f printPosition;

};

